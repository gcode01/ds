import { IdoPoolBaseInfo } from './type'

export const IDO_POOLS: IdoPoolBaseInfo[] = [
  { id: 'GQAJxy4qdckdevK3MRbRnTep4dvPLTfbRsgiX1izMY4K', version: 3, snapshotVersion: 1 }
]
