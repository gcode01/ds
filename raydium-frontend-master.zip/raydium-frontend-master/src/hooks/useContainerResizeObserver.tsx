// TODO: a hook that use ResizeObserver. Should not confuse it with useWindowMedia()
export default function useContainerResizeObserver() {
  throw new Error('Hook not implemented.')
}
